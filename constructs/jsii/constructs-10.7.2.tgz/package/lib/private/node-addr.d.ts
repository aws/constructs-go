/**
 * Separator used to delimit path components while calculating an address.
 *
 * Ids are sanitized before they become path components (see `sanitizeId()` in
 * `construct.ts`), so that a single component never contains this character.
 * Otherwise one component could hash like several: the single component
 * `a<sep>b` would be fed to the hash exactly like the two components `a` and
 * `b`.
 */
export declare const ADDR_SEP = "\n";
/**
 * Calculates the construct addr based on path components.
 *
 * Components named `Default` (case sensitive) are excluded from addr
 * calculation to allow tree refactorings.
 */
export declare function addressOf(components: string[]): string;
